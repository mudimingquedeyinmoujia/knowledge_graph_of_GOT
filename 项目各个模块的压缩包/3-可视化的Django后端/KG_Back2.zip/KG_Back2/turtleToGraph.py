from django.shortcuts import render
from SPARQLWrapper import SPARQLWrapper, JSON
from . import globalsetting

host=globalsetting.getGlobalHost()
# 对于一条三元组，识别出对应的节点类型，生成节点，添加到节点列表
# 如果节点列表没有的话，添加之后返回两个脚标；如果节点列表已有的话，返回已存在的脚标
# 在连接列表添加两个脚标的链接信息

# ----  nodes
#  id
#  name  节点名称
#  value
#  category  节点分类索引
#  symbolSize 节点大小
#
# ----  links
#  source
#  target
#  label
#    show
#    formatter



def transForm(jsonmsg):
    bindinglist=jsonmsg["results"]["bindings"]
    ans={}
    ans["type"]="force"
    ans["categories"]=[]
    ans["categories"].append({"name": "人物", "keyword": {}, "base": "人物节点"})
    ans["categories"].append({"name": "家族", "keyword": {}, "base": "家族节点"})
    ans["categories"].append({"name": "城堡", "keyword": {}, "base": "城堡节点"})
    ans["categories"].append({"name": "属性", "keyword": {}, "base": "属性节点"})
    # catelist=[]
    # cateitem={}
    # name 分类名称
    # keyword  {}
    # base 基准图节点
    nodelist=[]
    nodeitem={}
    # name 节点名称
    # value 默认为1
    # category 所属的分类索引
    linklist=[]
    # source
    # target
    linkitem={}
    for item in bindinglist:
        nodex=getNodeitem(item["x"])
        sourceindex=judgeNode(nodelist,nodex)
        nodez=getNodeitem(item["z"])
        targetindex=judgeNode(nodelist,nodez)
        linknode=getLinkitem(sourceindex,targetindex,parseUrl(item["y"]["value"]))
        linklist.append(linknode)

    ans["nodes"]=nodelist
    ans["links"]=linklist

    for item in nodelist:
        if item["name"]=="character":
            item["symbolSize"]=0
            item["category"]=0
        elif item["name"]=="house":
            item["symbolSize"] = 0
            item["category"] = 1
        elif item["name"]=="castle":
            item["symbolSize"] = 0
            item["category"] = 2

    return ans

def transFormEasy(jsonmsg):
    ans={}
    ans["type"] = "force"
    ans["categories"] = [{"name":"人物","keyword":{},"base":"人物节点"}]
    ans["categories"].append({"name":"家族","keyword":{},"base":"家族节点"})
    ans["categories"].append({"name":"城堡","keyword":{},"base":"城堡节点"})
    ans["categories"].append({"name":"属性","keyword":{},"base":"属性节点"})
    ans["nodes"] = []
    ans["nodes"].append({"name":"人物1","value":1,"category":0})
    ans["nodes"].append({"name":"人物2","value":1,"category":0})
    ans["nodes"].append({"name":"人物3","value":1,"category":0})
    ans["nodes"].append({"name":"人物4","value":1,"category":0})
    ans["nodes"].append({"name":"家族1","value":1,"category":1})
    ans["nodes"].append({"name":"家族2","value":1,"category":1})
    ans["nodes"].append({"name":"家族3","value":1,"category":1})
    ans["nodes"].append({"name":"城堡1","value":1,"category":2})
    ans["nodes"].append({"name":"城堡2","value":1,"category":2})
    ans["nodes"].append({"name":"城堡3","value":1,"category":2})
    ans["nodes"].append({"name":"人物节点","value":3,"category":0})
    ans["nodes"].append({"name":"家族节点","value":3,"category":1})
    ans["nodes"].append({"name":"城堡节点","value":3,"category":2})
    ans["links"] = []
    ans["links"].append({"source":0,"target":4})
    ans["links"].append({"source":0,"target":5})
    ans["links"].append({"source":1,"target":5})
    ans["links"].append({"source":2,"target":6})
    return ans

def getNodeitem(xorz):
    type=xorz["type"]
    name=xorz["value"]
    nameparse=parseUrl(name)
    nodeitem={"name":nameparse}
    nodeitem["value"]=1
    nodeitem["category"]=getCatgory(nameparse,type)
    nodeitem["symbolSize"]=5
    return nodeitem

def parseUrl(name):
    strlist=name.split("/")
    str=strlist[len(strlist)-1]
    return str

# 传入名字和类型（uri或者literal）得到数值类型的分类
def getCatgory(nameparse,type):
    if type == "uri":
        nameparse="\""+nameparse+"\""
        sparql = SPARQLWrapper(host)
        sparql.setQuery("""
            PREFIX r: <http://kg.course/action/>
            PREFIX e: <http://kg.course/entity/>

            SELECT DISTINCT ?z
            WHERE {
                 ?x ?y ?z.
            """+ "?x r:name "+nameparse+"."+"""
                 ?x r:type ?z.

            }
            """)
        sparql.setReturnFormat(JSON)
        results = sparql.query().convert()
        if (len(results["results"]["bindings"])==0):return 0
        whattype=results["results"]["bindings"][0]["z"]["value"]
        if whattype == "character":
            return 0
        elif whattype == "house":
            return 1
        else: return 2
    else:
        return 3

def judgeNode(nodelist,node):
    for i in range(len(nodelist)):
        if nodelist[i]["name"] == node["name"] and nodelist[i]["category"]==node["category"]:
            if(not (nodelist[i]["name"] == ("character" or "house" or "castle"))):
                nodelist[i]["symbolSize"] +=1

            return i

    nodelist.append(node)
    return len(nodelist)-1

def getLinkitem(sourceindex,targetindex,relation):
    linknode={"source":sourceindex,"target":targetindex}
    label={"show":True,"formatter":relation}
    linknode["label"]=label
    return linknode

# 测试未分类的三元组用，最终无用
def graphtesttemp(jsonmsg):
    bindinglist=jsonmsg["results"]["bindings"]
    ans={}
    ans["type"]="force"
    ans["categories"]=[]
    ans["categories"].append({"name": "未区分类别", "keyword": {}, "base": "未区分类别"})
    # catelist=[]
    # cateitem={}
    # name 分类名称
    # keyword  {}
    # base 基准图节点
    nodelist=[]
    nodeitem={}
    # name 节点名称
    # value 默认为1
    # category 所属的分类索引
    linklist=[]
    # source
    # target
    linkitem={}
    for item in bindinglist:
        nodex=getNodeitemtest(item["x"])
        sourceindex=judgeNode(nodelist,nodex)
        nodez=getNodeitemtest(item["z"])
        targetindex=judgeNode(nodelist,nodez)
        linknode=getLinkitem(sourceindex,targetindex,parseUrl(item["y"]["value"]))
        linklist.append(linknode)

    ans["nodes"]=nodelist
    ans["links"]=linklist

    return ans
# 最终无用
def getNodeitemtest(xorz):
    type = xorz["type"]
    name = xorz["value"]
    nameparse = parseUrl(name)
    nodeitem = {"name": nameparse}
    nodeitem["value"] = 1
    nodeitem["category"] = 0
    nodeitem["symbolSize"]=5
    return nodeitem