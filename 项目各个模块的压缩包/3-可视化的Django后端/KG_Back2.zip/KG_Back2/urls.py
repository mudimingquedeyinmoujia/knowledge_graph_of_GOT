"""KG_Back2 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.urls import path

from . import view
from . import statistics
from . import visual
from . import search
from . import query
from . import markdown

urlpatterns = [
    path("find",view.find),
    # statistics 数据统计接口

    # 人物统计接口，返回小说中所有人物的名称，非三元组
    # 参数 limit 表示最多返回多少条
    # 参数默认值 50
    path("statistics/character",statistics.getCharacter),

    # 家族统计接口，返回小说中所有家族的名称，非三元组
    # 参数 limit 表示最多返回多少条
    # 参数默认值 50
    path("statistics/house",statistics.getHouse),

    # 城堡统计接口，返回小说中所有城堡的名称，非三元组
    # 参数 limit 表示最多返回多少条
    # 参数默认值 50
    path("statistics/castle",statistics.getCastle),

    # 人物关系统计接口，返回所有和人物相关的关系，非三元组，不重复
    # 参数 limit 表示最多返回多少条
    # 参数默认值 50
    path("statistics/relcharacter", statistics.getRelCharacter),

    # 家族关系统计接口，返回所有和家族相关的关系，非三元组，不重复
    # 参数 limit 表示最多返回多少条
    # 参数默认值 50
    path("statistics/relhouse", statistics.getRelHouse),

    # 城堡关系统计接口，返回所有和城堡相关的关系，非三元组，不重复
    # 参数 limit 表示最多返回多少条
    # 参数默认值 50
    path("statistics/relcastle", statistics.getRelCastle),

    # 人物特定关系统计接口，返回所有和人物某个特定关系相关的名称（因为人物的某个关系比如“头衔”对于整体来说是有很多不同的具体名称的），非三元组，不重复
    # 参数 name 表示特定的关系名称
    # 参数默认值 name
    path("statistics/characterRelOf",statistics.getCharacterRelOf),

    # 家族特定关系统计接口，返回所有和家族某个特定关系相关的名称，非三元组，不重复
    # 参数 name 表示特定的关系名称
    # 参数默认值 name
    path("statistics/houseRelOf",statistics.getHouseRelOf),

    # 城堡特定关系统计接口，返回所有和城堡某个特定关系相关的名称，非三元组，不重复
    # 参数 name 表示特定的关系名称
    # 参数默认值 name
    path("statistics/castleRelOf",statistics.getCastleRelOf),

    path("statistics/getRel",statistics.getRel),

    # 某个特定的实体所有的关系，比如A人物有“头衔”关系，然而B人物没有，这个接口就是统计某个特定的人到底有多少关系
    # 参数 name 表示实体的名称，可以是人物、家族、城堡名称
    # 参数默认值 琼恩·雪诺
    path("statistics/getSomeoneRel",statistics.getSomeoneRel),

    # 返回jena fuseki服务器中的三元组关系总数量
    # 无参数
    # 返回参数 json:
    # 1. count (三元组总数量)
    path("statistics/getAllCount",statistics.getAllCount),

    # 关系数量统计接口，接收POST请求，请求内容为关系名称字符串序列，返回各个关系数量的数组
    # 接收参数 json :
    # 1. arr (表示关系字符串序列)
    # 2. type (表示关系字符串所属的类别,如character、house、castle
    # 返回参数 json :
    # 1. numarr (表示数值数组)
    # 无默认值
    path("statistics/getArrayNum",statistics.getArrayNum),



    # visual 可视化接口

    # 返回所有三元组
    path("visual/all",visual.getAll),

    # 返回部分三元组
    # 参数 limit 默认 50
    path("visual/some",visual.getSome),

    # 返回一个特定名称的所有相关三元组
    # 参数 name  默认 琼恩·雪诺
    path("visual/getOne",visual.getOne),



    # 可视化接口图相关接口，会调用三元组转换图结构的解析引擎，返回的格式将不是三元组的json,而是便于echarts进行图结构可视化的json

    # 返回所有的图
    path("visual/graph/all",visual.getGraphAll),

    # 返回部分图结构
    # 参数 limit 默认50
    # 即返回limit个三元组所代表的图结构
    path("visual/graph/some",visual.getGraphSome),

    # 返回某一个人的图结构
    # 参数 name 默认为 琼恩·雪诺
    path("visual/graph/getOne",visual.getGraphOne),

    # 返回测试图结构，高度自定义图结构，测试用
    path("visual/graph/graphtest",visual.graphtest),

    # 返回三元组图结构，未进行关系抽取的时候使用，测试用
    path("visual/graph/graphtesttemp",visual.graphtesttemp),

    # 返回可以静态显示的图结构
    path("visual/staticGraph/all",visual.getStaticGraphAll),

    # 返回可以静态显示的图结构的某一个点及其关联的点
    # 接收参数POST
    # name 字符串，要查询的实体名称
    # graphlist 字典，包括
    ### type
    ### categories
    ### nodes
    ### links
    path("visual/staticGraph/one",visual.getStaticGraphOne),
    path("visual/staticGraph/oneSimp",visual.getStaticGraphOneSimp),

    # search 用户普通查询
    # 未完善
    path("search",search.searchit),

    # query 用户高级查询
    path("query",query.queryit),

    path("markdown/test",markdown.test),
    path("markdown/howmany",markdown.howmany),
    path("markdown/what",markdown.what)
]