import json

import os
# 项目目录
path=os.getcwd()+r"\KG_Back2"
graph_path=path+r"\graphstore\graph.json"
graph_path_all=path+r"\graphstore\graph.json"

def getGraph():
    with open(graph_path) as graph_file:
        graph=json.load(graph_file)

    return graph

# 测试失败
# def getNewLinkNode(linknode,all_nodelist):
#     source=linknode["source"]
#     target=linknode["target"]
#     new_linknode={}
#     new_linknode["source"]=all_nodelist[source]["name"]
#     new_linknode["target"]=all_nodelist[target]["name"]
#     new_linknode["sourcePre"]=source
#     new_linknode["targetPre"]=target
#     label = linknode["label"]
#     label["position"]="end"
#     label["padding"]=[100,0,0,0]
#     label["align"]="center"
#     label["color"] = "#ffd04b"
#     # label["verticalAlign"] = "middle"
#     new_linknode["label"]=label
#     return new_linknode
#
# def haveNode(alreadyNodelist,node):
#     for item in alreadyNodelist:
#         if item["id"]==node["id"]:
#             return True
#
#     return False
#
# def haveLink(alreadyLinkList,link):
#     for item in alreadyLinkList:
#         if item["sourcePre"]==link["sourcePre"] and item["targetPre"]==link["targetPre"]:
#             return True
#
#     return False
################################################################
def ifHaveNode(alreadyNodelist,node):

    for i in range(len(alreadyNodelist)):
        if alreadyNodelist[i]["name"]==node["name"] and alreadyNodelist[i]["category"]==node["category"]:
            return i

    return -1

def storeNode(nodelist,node):
    nodelist.append(node)
    return len(nodelist)-1

def getNewLinkNode(source,target,linknode):
    new_linknode=linknode
    new_linknode["source"]=source
    new_linknode["target"]=target
    label = linknode["label"]
    label["position"]="end"
    label["padding"]=[100,0,0,0]
    label["align"]="center"
    label["color"] = "#409eff"
    new_linknode["label"]=label
    return new_linknode

def ifHaveLink(linklist,linknode):
    for i in range(len(linklist)):
        if linklist[i]["source"]==linknode["source"] and linklist[i]["target"]==linknode["target"]:
            return True

    return False

def getOne(msg):
    name=msg["name"]
    graphlist=msg["graphlist"]
    already_nodelist=graphlist["nodes"]
    already_linklist=graphlist["links"]

    with open(graph_path_all) as graph_path_all_file:
        graph=json.load(graph_path_all_file)

    bis_index=len(already_nodelist)
    ans_nodelist=[]
    ans_linklist=[]
    all_nodelist=graph["nodes"]
    all_linklist=graph["links"]
    # 接收要查询的name,接收已经存在的list
    # 返回补充的list，前端再补充进去

    for i in range(len(all_nodelist)):
        if all_nodelist[i]["name"]==name and all_nodelist[i]["category"]!=3 :
            keynode=all_nodelist[i]
            keysource=0
            if ifHaveNode(already_nodelist,keynode) == -1:
                ans_nodelist.append(keynode)
                keysource=bis_index+keysource
            else:
                keysource=ifHaveNode(already_nodelist,keynode)

            for j in range(len(all_linklist)):
                if all_linklist[j]["source"]==i:
                    target=all_linklist[j]["target"]
                    targetnode=all_nodelist[target]
                    if ifHaveNode(already_nodelist,targetnode) ==-1:
                        keytarget=storeNode(ans_nodelist,targetnode)+bis_index
                    else:
                        keytarget=ifHaveNode(already_nodelist,targetnode)

                    new_linknode=getNewLinkNode(keysource,keytarget,all_linklist[j])
                    if ifHaveLink(already_linklist,new_linknode) is False:
                        ans_linklist.append(new_linknode)



    # for i in range(len(all_nodelist)):
    #     if all_nodelist[i]["name"]==name:
    #         key_node=all_nodelist[i]
    #         key_node["id"]=i
    #         if haveNode(already_nodelist,key_node) is False:
    #             ans_nodelist.append(key_node)
    #
    #         for j in range(len(all_linklist)):
    #             if all_linklist[j]["source"]==i:
    #                 rel_linkNode=getNewLinkNode(all_linklist[j],all_nodelist)
    #                 if haveLink(already_linklist,rel_linkNode) is False:
    #                     ans_linklist.append(rel_linkNode)
    #                 target_node_index=all_linklist[j]["target"]
    #                 targetnode=all_nodelist[target_node_index]
    #                 targetnode["id"]=target_node_index
    #                 if haveNode(already_nodelist,key_node) is False:
    #                     ans_nodelist.append(targetnode)


    # for i in range(len(nodelist)):
    #     if(nodelist[i]["name"]==name):
    #         ans_nodelist.append(nodelist[i])
    #         for j in range(len(linklist)):
    #             if(linklist[j]["source"]==i):
    #                 linknode=getNewLinkItem(0,len(ans_nodelist),linklist[j])
    #                 ans_linklist.append(linknode)
    #                 targetindex=linklist[j]["target"]
    #                 ans_nodelist.append(nodelist[targetindex])

    ans = {}
    ans["type"] = "none"
    ans["categories"] = []
    ans["categories"].append({"name": "人物", "keyword": {}, "base": "人物节点"})
    ans["categories"].append({"name": "家族", "keyword": {}, "base": "家族节点"})
    ans["categories"].append({"name": "城堡", "keyword": {}, "base": "城堡节点"})
    ans["categories"].append({"name": "属性", "keyword": {}, "base": "属性节点"})

    for item in ans_nodelist:
        item["symbolSize"]=20

    ans["nodes"]=ans_nodelist
    ans["links"]=ans_linklist
    return ans


def getOneSimp(msg):
    name=msg["name"]
    graphlist=msg["graphlist"]
    already_nodelist=graphlist["nodes"]
    already_linklist=graphlist["links"]

    with open(graph_path_all) as graph_path_all_file:
        graph=json.load(graph_path_all_file)

    bis_index=len(already_nodelist)
    ans_nodelist=[]
    ans_linklist=[]
    all_nodelist=graph["nodes"]
    all_linklist=graph["links"]
    # 接收要查询的name,接收已经存在的list
    # 返回补充的list，前端再补充进去

    for i in range(len(all_nodelist)):
        if all_nodelist[i]["name"]==name and all_nodelist[i]["category"]!=3 :
            keynode=all_nodelist[i]
            keysource=0
            if ifHaveNode(already_nodelist,keynode) == -1:
                ans_nodelist.append(keynode)
                keysource=bis_index+keysource
            else:
                keysource=ifHaveNode(already_nodelist,keynode)

            for j in range(len(all_linklist)):
                if all_linklist[j]["source"]==i:
                    target=all_linklist[j]["target"]
                    targetnode=all_nodelist[target]
                    if ifHaveNode(already_nodelist,targetnode) ==-1:
                        keytarget=storeNode(ans_nodelist,targetnode)+bis_index
                    else:
                        keytarget=ifHaveNode(already_nodelist,targetnode)

                    new_linknode=getNewLinkNode(keysource,keytarget,all_linklist[j])
                    if ifHaveLink(already_linklist,new_linknode) is False:
                        ans_linklist.append(new_linknode)


    ans = {}
    ans["type"] = "none"
    ans["categories"] = []
    ans["categories"].append({"name": "人物", "keyword": {}, "base": "人物节点"})
    ans["categories"].append({"name": "家族", "keyword": {}, "base": "家族节点"})
    ans["categories"].append({"name": "城堡", "keyword": {}, "base": "城堡节点"})
    ans["categories"].append({"name": "属性", "keyword": {}, "base": "属性节点"})


    ans["nodes"]=ans_nodelist
    ans["links"]=ans_linklist
    return ans
