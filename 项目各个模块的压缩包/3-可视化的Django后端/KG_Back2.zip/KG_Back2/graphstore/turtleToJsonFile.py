import json
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
from SPARQLWrapper import SPARQLWrapper, JSON
import random
from .. import globalsetting
host = globalsetting.getGlobalHost()
# LIMIT 是多少
# link 里面是不是显示边的名称
# 画面长宽和半径
# 保存的文件夹名称
###################################################

def getNodeitem(xorz):
    type=xorz["type"]
    name=xorz["value"]
    nameparse=parseUrl(name)
    nodeitem={"name":nameparse}
    nodeitem["value"]=1
    nodeitem["category"]=getCatgory(nameparse,type)
    nodeitem["symbolSize"]=5
    return nodeitem

def parseUrl(name):
    strlist=name.split("/")
    str=strlist[len(strlist)-1]
    return str

# 传入名字和类型（uri或者literal）得到数值类型的分类
def getCatgory(nameparse,type):
    if type == "uri":
        nameparse="\""+nameparse+"\""
        sparql = SPARQLWrapper(host)
        sparql.setQuery("""
            PREFIX r: <http://kg.course/action/>
            PREFIX e: <http://kg.course/entity/>

            SELECT DISTINCT ?z
            WHERE {
                 ?x ?y ?z.
            """+ "?x r:name "+nameparse+"."+"""
                 ?x r:type ?z.

            }

            """)
        sparql.setReturnFormat(JSON)
        results = sparql.query().convert()
        if (len(results["results"]["bindings"])==0):return 0
        whattype=results["results"]["bindings"][0]["z"]["value"]
        if whattype == "character":
            return 0
        elif whattype == "house":
            return 1
        else: return 2
    else:
        return 3

def judgeNode(nodelist,node):
    for i in range(len(nodelist)):
        if nodelist[i]["name"] == node["name"] and nodelist[i]["category"]==node["category"]:
            # 如果节点不是三者其中之一
            if(not (nodelist[i]["name"] == ("character" or "house" or "castle"))):
                nodelist[i]["symbolSize"] +=1

            return True,i

    nodelist.append(node)
    return False,len(nodelist)-1

############## 1. 这里设置边是否显示
##############
def getLinkitem(sourceindex,targetindex,relation):
    linknode={"source":sourceindex,"target":targetindex}
    label={"show":True,"formatter":relation}
    linknode["label"]=label
    return linknode

def getLocationInBeside(x,y,r,loss):
    while(True):
        new_x=random.randint(0,r*2+loss*2)
        new_y=random.randint(0,r*2+loss*2)
        if((r-new_x)**2+(r-new_y)**2 > (r-loss)**2 and (r-new_x)**2+(r-new_y)**2 < (r+loss)**2):
            return new_x-r+x,new_y-r+y

def getRandomLocation(r,max,may):
    x=random.randint(r,max-r)
    y=random.randint(r,may-r)
    return x,y

def givelocation(nodelist,index,x,y):
    item=nodelist[index]
    item["x"]=x
    item["y"]=y

def getReadyLocation(nodelist,index):
    item=nodelist[index]
    return item["x"],item["y"]
# 从服务器获取所有三元组
# 对每一个三元组获取图结构的node和link所有的属性
# 得到json后存储
##################################################

sparql = SPARQLWrapper(host)

############## 2. 这里设置获取三元组数量
##############
sparql.setQuery("""
        PREFIX r: <http://kg.course/action/>
        PREFIX e: <http://kg.course/entity/>

        SELECT ?x ?y ?z
        WHERE {
            ?x ?y ?z.
        }
        
""")
sparql.setReturnFormat(JSON)
results = sparql.query().convert()
# 得到三元组列表
turtle_list=results["results"]["bindings"]
# 这是最终的目标结果json
ans={}
ans["type"]="none"
ans["categories"]=[]
ans["categories"].append({"name": "人物", "keyword": {}, "base": "人物节点"})
ans["categories"].append({"name": "家族", "keyword": {}, "base": "家族节点"})
ans["categories"].append({"name": "城堡", "keyword": {}, "base": "城堡节点"})
ans["categories"].append({"name": "属性", "keyword": {}, "base": "属性节点"})
nodelist=[]
linklist=[]

# x 不在列表  z 不在列表  随机生成x, z如果是实体，随机生成，z如果是属性，生成z在x附近半径
# x 不在列表  z 在列表    随机生成x z不生成
# x 在列表   z 不在列表   x 不生成,  z如果是实体，随机生成，z如果是属性，生成z在x附近半径
# x 在列表   z 在列表    建立关系

############## 3. 这里设置长宽各种半径
##############
# limit=2000
# r=3500
# max=100000
# may=50000
# r_circle=3000
# loss=500

# limit=all
r=35000
max=1000000
may=500000
r_circle=30000
loss=5000
for item in turtle_list:

    if parseUrl(item["y"]["value"])=="type": continue
    nodex = getNodeitem(item["x"])
    if_have_x,sourceindex = judgeNode(nodelist, nodex)
    nodez = getNodeitem(item["z"])
    if_hava_z,targetindex = judgeNode(nodelist, nodez)
    linknode = getLinkitem(sourceindex, targetindex, parseUrl(item["y"]["value"]))
    linklist.append(linknode)
    if if_have_x is False and if_hava_z is False:
        loc_x,loc_y=getRandomLocation(r,max,may)
        givelocation(nodelist,sourceindex,loc_x,loc_y)
        if item["z"]["type"] == "uri":
            loc_x_z,loc_y_z=getRandomLocation(r,max,may)
        else:
            loc_x_z,loc_y_z=getLocationInBeside(loc_x,loc_y,r_circle,loss)

        givelocation(nodelist,targetindex,loc_x_z,loc_y_z)

    elif if_have_x is False and if_hava_z is True:
        loc_x, loc_y = getRandomLocation(r, max,may)
        givelocation(nodelist, sourceindex, loc_x, loc_y)

    elif if_have_x is True and if_hava_z is False:
        loc_x,loc_y=getReadyLocation(nodelist,sourceindex)
        if item["z"]["type"] == "uri":
            loc_x_z, loc_y_z = getRandomLocation(r, max,may)
        else:
            loc_x_z, loc_y_z = getLocationInBeside(loc_x, loc_y, r_circle, loss)

        givelocation(nodelist, targetindex, loc_x_z, loc_y_z)


ans["nodes"] = nodelist
ans["links"] = linklist

ans["nodes"]=nodelist
ans["links"]=linklist

for item in nodelist:
    if item["name"]=="character":
            item["symbolSize"]=0
            item["category"]=0
    elif item["name"]=="house":
            item["symbolSize"] = 0
            item["category"] = 1
    elif item["name"]=="castle":
            item["symbolSize"] = 0
            item["category"] = 2


############## 4. 这里设置存储文件的名称
##############
# 存储的文件路径
graph_path="graph.json"

# 最后一步
with open(graph_path,"w") as graph_file:
    json.dump(ans,graph_file)

# 存储成功
print("store ok")
