from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
from SPARQLWrapper import SPARQLWrapper, JSON

def find(request):
    gag={}
    gag["ha"]="hehe"
    gag["xi"]="xixi"
    return JsonResponse(gag)