from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from SPARQLWrapper import SPARQLWrapper, JSON
import json
from . import turtleToGraph
from .graphstore import readJson
import os
# 项目目录
path=os.getcwd()+r"\KG_Back2"
mdfile= path+r"\mdfiles\test.md"
dirpath=path+r"\mdfiles"

def test(request):
    with open( mdfile,'r', encoding='utf-8') as md:
        content=md.read()
        ans={}
        ans["md"]=content
        return JsonResponse(ans)

def howmany(request):
    dir = path
    dir += r"\mdfiles"
    filelist = os.listdir(dir)
    ans={}
    ans["filelist"]=filelist
    return JsonResponse(ans)

def what(request):
    filename=request.GET["name"]
    fullpath=dirpath+"\\"+filename
    with open(fullpath,'r',encoding='utf-8') as md:
        content=md.read()
        ans={}
        ans["md"]=content
        return JsonResponse(ans)