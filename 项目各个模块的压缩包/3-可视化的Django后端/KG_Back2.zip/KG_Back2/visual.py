from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from SPARQLWrapper import SPARQLWrapper, JSON
import json
from . import turtleToGraph
from .graphstore import readJson
from . import globalsetting

host= globalsetting.getGlobalHost()

def getAll(request):
    sparql = SPARQLWrapper(host)
    sparql.setQuery("""
                PREFIX r: <http://kg.course/action/>
                PREFIX e: <http://kg.course/entity/>

                SELECT DISTINCT ?x ?y ?z
                WHERE {
                    ?x ?y ?z.

                }
                """)
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()
    return JsonResponse(results)


def getSome(request):
    limit = 50
    if 'limit' in request.GET and request.GET['limit']:
        limit = request.GET['limit']

    sparql = SPARQLWrapper(host)
    sparql.setQuery("""
                PREFIX r: <http://kg.course/action/>
                PREFIX e: <http://kg.course/entity/>

                SELECT DISTINCT ?x ?y ?z
                WHERE {
                    ?x ?y ?z.
                }
                """ + "LIMIT " + str(limit))
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()
    return JsonResponse(results)


def getOne(request):
    name = "琼恩·雪诺"
    if 'name' in request.GET and request.GET['name']:
        name = request.GET['name']

    name = "\"" + name + "\""
    sparql = SPARQLWrapper(host)
    sparql.setQuery("""
                PREFIX r: <http://kg.course/action/>
                PREFIX e: <http://kg.course/entity/>

                SELECT DISTINCT ?x ?y ?z
                WHERE {
                    ?x ?y ?z.

                """ + "?x r:name " + name + "." + """

                }
                """)
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()
    return JsonResponse(results)


def getGraphAll(request):
    sparql = SPARQLWrapper(host)
    sparql.setQuery("""
                    PREFIX r: <http://kg.course/action/>
                    PREFIX e: <http://kg.course/entity/>

                    SELECT DISTINCT ?x ?y ?z
                    WHERE {
                        ?x ?y ?z.

                    }
                    """)
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()
    ans = turtleToGraph.transForm(results)
    return JsonResponse(ans)


def getGraphSome(request):
    limit = 50
    if 'limit' in request.GET and request.GET['limit']:
        limit = request.GET['limit']

    sparql = SPARQLWrapper(host)
    sparql.setQuery("""
                    PREFIX r: <http://kg.course/action/>
                    PREFIX e: <http://kg.course/entity/>

                    SELECT DISTINCT ?x ?y ?z
                    WHERE {
                        ?x ?y ?z.
                    }
                    """ + "LIMIT " + str(limit))
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()
    ans = turtleToGraph.transForm(results)
    return JsonResponse(ans)


def getGraphOne(request):
    name = "琼恩·雪诺"
    if 'name' in request.GET and request.GET['name']:
        name = request.GET['name']

    name = "\"" + name + "\""
    sparql = SPARQLWrapper(host)
    sparql.setQuery("""
                    PREFIX r: <http://kg.course/action/>
                    PREFIX e: <http://kg.course/entity/>

                    SELECT DISTINCT ?x ?y ?z
                    WHERE {
                        ?x ?y ?z.

                    """ + "?x r:name " + name + "." + """

                    }
                    """)
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()
    ans = turtleToGraph.transForm(results)
    return JsonResponse(ans)


def graphtest(request):
    msg = "haha"
    results = turtleToGraph.transFormEasy(msg)
    return JsonResponse(results)


# 测试用，正式不用
def graphtesttemp(request):
    limit = 50
    if 'limit' in request.GET and request.GET['limit']:
        limit = request.GET['limit']

    sparql = SPARQLWrapper("http://localhost:3030/testdata")
    sparql.setQuery("""
                        PREFIX r: <http://kg.course/action/>
                        PREFIX e: <http://kg.course/entity/>

                        SELECT DISTINCT ?x ?y ?z
                        WHERE {
                            ?x ?y ?z.
                        }
                        """ + "LIMIT " + str(limit))
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()
    ans = turtleToGraph.graphtesttemp(results)
    return JsonResponse(ans)


def getStaticGraphAll(request):
    ans = readJson.getGraph()
    return JsonResponse(ans)


@csrf_exempt
def getStaticGraphOne(request):
    receive_data = json.loads(request.body.decode())
    name = receive_data["name"]
    graphlist = receive_data["graphlist"]

    if name == '': name = "琼恩·雪诺"

    graphlist["type"] = "none"
    graphlist["categories"] = []
    graphlist["categories"].append({"name": "人物", "keyword": {}, "base": "人物节点"})
    graphlist["categories"].append({"name": "家族", "keyword": {}, "base": "家族节点"})
    graphlist["categories"].append({"name": "城堡", "keyword": {}, "base": "城堡节点"})
    graphlist["categories"].append({"name": "属性", "keyword": {}, "base": "属性节点"})

    msg = {}
    msg["name"] = name
    msg["graphlist"] = graphlist

    ans = readJson.getOne(msg)
    return JsonResponse(ans)


@csrf_exempt
def getStaticGraphOneSimp(request):
    receive_data = json.loads(request.body.decode())
    name = receive_data["name"]
    graphlist = receive_data["graphlist"]

    if name == '': name = "琼恩·雪诺"

    graphlist["type"] = "none"
    graphlist["categories"] = []
    graphlist["categories"].append({"name": "人物", "keyword": {}, "base": "人物节点"})
    graphlist["categories"].append({"name": "家族", "keyword": {}, "base": "家族节点"})
    graphlist["categories"].append({"name": "城堡", "keyword": {}, "base": "城堡节点"})
    graphlist["categories"].append({"name": "属性", "keyword": {}, "base": "属性节点"})

    msg = {}
    msg["name"] = name
    msg["graphlist"] = graphlist

    ans = readJson.getOneSimp(msg)
    return JsonResponse(ans)