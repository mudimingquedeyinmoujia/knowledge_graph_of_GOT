import os

dir=os.getcwd()
dir+=r"\mdfiles"
filelist=os.listdir(dir)

print(filelist)