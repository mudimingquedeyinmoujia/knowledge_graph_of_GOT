from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
from SPARQLWrapper import SPARQLWrapper, JSON
from django.views.decorators.csrf import csrf_exempt
from . import globalsetting


host=globalsetting.getGlobalHost()


def getCharacter(request):
    limit = 50
    if 'limit' in request.GET and request.GET['limit']:
        limit = request.GET['limit']

    print(limit)
    sparql = SPARQLWrapper(host)
    sparql.setQuery("""
                PREFIX r: <http://kg.course/action/>
                PREFIX e: <http://kg.course/entity/>

                SELECT DISTINCT ?z
                WHERE {
                    ?x ?y ?z.
                    ?x r:type "character".
                    ?x r:name ?z.
                }
                """ + "LIMIT " + str(limit))
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()
    return JsonResponse(results)


def getHouse(request):
    limit = 50
    if 'limit' in request.GET and request.GET['limit']:
        limit = request.GET['limit']

    sparql = SPARQLWrapper(host)
    sparql.setQuery("""
                PREFIX r: <http://kg.course/action/>
                PREFIX e: <http://kg.course/entity/>

                SELECT DISTINCT ?z
                WHERE {
                    ?x ?y ?z.
                    ?x r:type "house".
                    ?x r:name ?z.
                }
                """ + "LIMIT " + str(limit))
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()
    return JsonResponse(results)


def getCastle(request):
    limit = 50
    if 'limit' in request.GET and request.GET['limit']:
        limit = request.GET['limit']

    sparql = SPARQLWrapper(host)
    sparql.setQuery("""
                PREFIX r: <http://kg.course/action/>
                PREFIX e: <http://kg.course/entity/>

                SELECT DISTINCT ?z
                WHERE {
                    ?x ?y ?z.
                    ?x r:type "castle".
                    ?x r:name ?z.
                }
                """ + "LIMIT " + str(limit))
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()
    return JsonResponse(results)


def getRelCharacter(request):
    limit = 50
    if 'limit' in request.GET and request.GET['limit']:
        limit = request.GET['limit']

    sparql = SPARQLWrapper(host)
    sparql.setQuery("""
                PREFIX r: <http://kg.course/action/>
                PREFIX e: <http://kg.course/entity/>

                SELECT DISTINCT ?y
                WHERE {
                    ?x ?y ?z.
                    ?x r:type "character".
                }
                """ + "LIMIT " + str(limit))
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()
    return JsonResponse(results)


def getRelHouse(request):
    limit = 50
    if 'limit' in request.GET and request.GET['limit']:
        limit = request.GET['limit']

    sparql = SPARQLWrapper(host)
    sparql.setQuery("""
                PREFIX r: <http://kg.course/action/>
                PREFIX e: <http://kg.course/entity/>

                SELECT DISTINCT ?y
                WHERE {
                    ?x ?y ?z.
                    ?x r:type "house".
                }
                """ + "LIMIT " + str(limit))
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()
    return JsonResponse(results)


def getRelCastle(request):
    limit = 50
    if 'limit' in request.GET and request.GET['limit']:
        limit = request.GET['limit']

    sparql = SPARQLWrapper(host)
    sparql.setQuery("""
                PREFIX r: <http://kg.course/action/>
                PREFIX e: <http://kg.course/entity/>

                SELECT DISTINCT ?y
                WHERE {
                    ?x ?y ?z.
                    ?x r:type "castle".
                }
                """ + "LIMIT " + str(limit))
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()
    return JsonResponse(results)


def getSomeoneRel(request):
    name = "琼恩·雪诺"
    if 'name' in request.GET and request.GET['name']:
        name = request.GET['name']

    name = "\"" + name + "\""
    sparql = SPARQLWrapper(host)
    sparql.setQuery("""
                PREFIX r: <http://kg.course/action/>
                PREFIX e: <http://kg.course/entity/>

                SELECT DISTINCT ?y
                WHERE {
                    ?x ?y ?z.

                """ + "?x r:name " + name + "." + """

                }
                """)
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()
    return JsonResponse(results)


def getAllCount(request):
    ans = {}
    sparql = SPARQLWrapper(host)
    sparql.setQuery("""
                PREFIX r: <http://kg.course/action/>
                PREFIX e: <http://kg.course/entity/>

                SELECT DISTINCT ?x ?y ?z
                WHERE {
                    ?x ?y ?z.

                }
                """)
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()
    ans['count'] = len(results['results']['bindings'])
    return JsonResponse(ans)


def getCharacterRelOf(request):
    name = "name"
    if 'name' in request.GET and request.GET['name']:
        name = request.GET['name']

    sparql = SPARQLWrapper(host)
    sparql.setQuery("""
                PREFIX r: <http://kg.course/action/>
                PREFIX e: <http://kg.course/entity/>

                SELECT DISTINCT ?z
                WHERE {
                    ?x ?y ?z.
                    ?x r:type "character".

                """ + "?x r:" + name + " ?z." + """

                }
                """)
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()
    return JsonResponse(results)


def getHouseRelOf(request):
    name = "name"
    if 'name' in request.GET and request.GET['name']:
        name = request.GET['name']

    sparql = SPARQLWrapper(host)
    sparql.setQuery("""
                PREFIX r: <http://kg.course/action/>
                PREFIX e: <http://kg.course/entity/>

                SELECT DISTINCT ?z
                WHERE {
                    ?x ?y ?z.
                    ?x r:type "house".

                """ + "?x r:" + name + " ?z." + """

                }
                """)
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()
    return JsonResponse(results)


def getCastleRelOf(request):
    name = "name"
    if 'name' in request.GET and request.GET['name']:
        name = request.GET['name']

    sparql = SPARQLWrapper(host)
    sparql.setQuery("""
                PREFIX r: <http://kg.course/action/>
                PREFIX e: <http://kg.course/entity/>

                SELECT DISTINCT ?z
                WHERE {
                    ?x ?y ?z.
                    ?x r:type "castle".

                """ + "?x r:" + name + " ?z." + """

                }
                """)
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()
    return JsonResponse(results)


def getRel(request):
    rel = "头衔"
    type = "character"
    name = "骑士"
    if 'name' in request.GET and request.GET['name']:
        name = request.GET['name']

    if 'type' in request.GET and request.GET['type']:
        type = request.GET['type']

    if 'rel' in request.GET and request.GET['rel']:
        rel = request.GET['rel']

    type = "\"" + type + "\""
    name_0 = "e:" + name
    name = "\"" + name + "\""

    sparql = SPARQLWrapper(host)
    sparql.setQuery("""
                    PREFIX r: <http://kg.course/action/>
                    PREFIX e: <http://kg.course/entity/>

                    SELECT DISTINCT ?x
                    WHERE {
                         ?x ?y ?z.
                    """ + "?x r:" + rel + " " + name + "." + "?x r:type " + type + "."

                    + """
                    }
                    """)
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()
    if len(results["results"]["bindings"]) == 0:
        sparql = SPARQLWrapper(host)
        sparql.setQuery("""
                            PREFIX r: <http://kg.course/action/>
                            PREFIX e: <http://kg.course/entity/>

                            SELECT DISTINCT ?x
                            WHERE {
                                 ?x ?y ?z.
                            """ + "?x r:" + rel + " " + name_0 + "." + "?x r:type " + type + "."

                        + """
                            }
                            """)
        sparql.setReturnFormat(JSON)
        results = sparql.query().convert()

    return JsonResponse(results)


@csrf_exempt
def getArrayNum(request):
    arrstr = request.POST['arr']
    type = request.POST['type']
    arr = arrstr.split(',')

    ansarr = [0 for i in range(len(arr))]
    if type == 'character':
        for i in range(len(arr)):
            ansarr[i] = getRelNumCha(arr[i])
            # print(ansarr[i])
    elif type == 'house':
        for i in range(len(arr)):
            ansarr[i] = getRelNumHou(arr[i])
    elif type == 'castle':
        for i in range(len(arr)):
            ansarr[i] = getRelNumCas(arr[i])

    final = {}
    final['numarr'] = ansarr
    return JsonResponse(final)


def getRelNumCha(name):
    sparql = SPARQLWrapper(host)
    sparql.setQuery("""
                PREFIX r: <http://kg.course/action/>
                PREFIX e: <http://kg.course/entity/>

                SELECT DISTINCT ?z
                WHERE {
                     ?x ?y ?z.
                     ?x r:type "character".
            """
                    + " ?x r:" + name + " ?z." + """
                }
    """)
    sparql.setReturnFormat(JSON)
    resultsarr = sparql.query().convert()['results']['bindings']
    return len(resultsarr)


def getRelNumHou(name):
    sparql = SPARQLWrapper(host)
    sparql.setQuery("""
                PREFIX r: <http://kg.course/action/>
                PREFIX e: <http://kg.course/entity/>

                SELECT DISTINCT ?z
                WHERE {
                     ?x ?y ?z.
                     ?x r:type "house".
            """
                    + " ?x r:" + name + " ?z." + """
                }
    """)
    sparql.setReturnFormat(JSON)
    resultsarr = sparql.query().convert()['results']['bindings']
    return len(resultsarr)


def getRelNumCas(name):
    sparql = SPARQLWrapper(host)
    sparql.setQuery("""
                PREFIX r: <http://kg.course/action/>
                PREFIX e: <http://kg.course/entity/>

                SELECT DISTINCT ?z
                WHERE {
                     ?x ?y ?z.
                     ?x r:type "castle".
            """
                    + " ?x r:" + name + " ?z." + """
                }
    """)
    sparql.setReturnFormat(JSON)
    resultsarr = sparql.query().convert()['results']['bindings']
    return len(resultsarr)