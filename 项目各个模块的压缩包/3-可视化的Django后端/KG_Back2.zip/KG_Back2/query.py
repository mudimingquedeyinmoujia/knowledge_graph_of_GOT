from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
from SPARQLWrapper import SPARQLWrapper, JSON
from django.views.decorators.csrf import csrf_exempt
from . import globalsetting
host=globalsetting.getGlobalHost()

@csrf_exempt
def queryit(request):
    print(request.POST)
    if not request.POST:
        name = "琼恩·雪诺"
        name = "\"" + name + "\""
        sparql = SPARQLWrapper(host)
        sparql.setQuery("""
                        PREFIX r: <http://kg.course/action/>
                        PREFIX e: <http://kg.course/entity/>

                        SELECT DISTINCT ?x ?y ?z
                        WHERE {
                            ?x ?y ?z.

                        """ + "?x r:name " + name + "." + """

                        }
                        """)
        sparql.setReturnFormat(JSON)
        results = sparql.query().convert()
        return JsonResponse(results)
    else:
        queryContent=request.POST['query']
        sparql = SPARQLWrapper(host)
        sparql.setQuery(queryContent)
        sparql.setReturnFormat(JSON)
        results=sparql.query().convert()
        return JsonResponse(results)