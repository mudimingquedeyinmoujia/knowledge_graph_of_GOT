def getGlobalHost():
    host = "http://localhost:3030/mytestdata2"
    return host