from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
from SPARQLWrapper import SPARQLWrapper, JSON
from . import globalsetting
host = globalsetting.getGlobalHost()

def searchit(request):
    if not request.POST:
        name = "琼恩·雪诺"
        name = "\"" + name + "\""
        sparql = SPARQLWrapper(host)
        sparql.setQuery("""
                        PREFIX r: <http://kg.course/action/>
                        PREFIX e: <http://kg.course/entity/>

                        SELECT DISTINCT ?x ?y ?z
                        WHERE {
                            ?x ?y ?z.

                        """ + "?x r:name " + name + "." + """

                        }
                        """)
        sparql.setReturnFormat(JSON)
        results = sparql.query().convert()
        return JsonResponse(results)
    else:
        sentence = request.POST['sentence']
        sparql = SPARQLWrapper(host)
        # 未完善
        # sparql.setQuery(parseEngine.parseSentence(sentence))
        sparql.setReturnFormat(JSON)
        results = sparql.query().convert()
        return JsonResponse(results)
