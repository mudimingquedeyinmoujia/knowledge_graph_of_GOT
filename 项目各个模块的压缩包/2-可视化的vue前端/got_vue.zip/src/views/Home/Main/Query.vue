<template>
    <div>
        <el-row>
             <el-col :span="12" :offset="6">
                 <h1 style="font-size:30px"><i class="el-icon-search" style="margin-right:20px"></i>专业查询</h1>
                 <h3>SPARQL QUERY</h3>
                 <p align="justify" style="margin:50px 0px">如果你是专业人士，并且熟悉sparql查询语句，想探索更加个性化的内容，那么这里是
                     专门为你打造的天地！尽情探索吧！
                 </p>
             </el-col>
        </el-row>
        <el-row  style="margin-bottom:20px">
            <el-col :span="12" :offset="6"><el-button type="primary" style="float:left" @click=getdata>点击查询</el-button></el-col>
        </el-row>
        <el-row >
            <el-col :span="12" :offset="6">
                <el-input
                    type="textarea"
                    :rows="14"
                    placeholder="请输入内容"
                    v-model="textarea">
                </el-input>
            </el-col>
        </el-row>
        <!-- 下面是列表 -->
        <el-row >
            <el-col :span="12" :offset="6">
                <el-table
    :data=tableData
    style="width: 100%"
    height="800">
    <el-table-column
      prop="subject"
      label="Subject"
      width="320">
    </el-table-column>
    <el-table-column
      prop="predicate"
      label="Predicate"
      width="320">
    </el-table-column>
    <el-table-column
      prop="object"
      label="Object"
      width="300">
    </el-table-column>
  </el-table>
            </el-col>
        </el-row>
    </div>
</template>
<script>
import axios from 'axios'
export default {
  data () {
    return {
      textarea: 'PREFIX r: <http://kg.course/action/>' + '\n' +
      'PREFIX e: <http://kg.course/entity/>' + '\n' +
      '' + '\n' +
      'SELECT DISTINCT ?x ?y ?z' + '\n' +
      'WHERE {' + '\n' +
      '' + '\n' +
      '?x ?y ?z.' + '\n' +
      '' + '\n' +
      '}' + '\n' +
      'LIMIT 100' + '\n',
      tableData: [],
      target: this.baseUrl() + 'query'
    }
  },
  methods: {
    getdata () {
      var that = this
      that.tableData = []
      const postdata = new FormData()
      postdata.append('query', that.textarea)
      axios.post(that.target, postdata).then(function (ret) {
        var datalist = ret.data.results.bindings
        for (var i = 0; i < datalist.length; i++) {
          var item = { subject: '', predicate: '', object: '' }
          item.subject = datalist[i].x.value
          item.predicate = datalist[i].y.value
          item.object = datalist[i].z.value
          that.tableData.push(item)
        }
      })
    }
  }
}
</script>
