<template>
     <div>
       <el-row>
             <el-col :span="12" :offset="6">
                 <h1 style="font-size:30px"><i class="el-icon-s-home" style="margin-right:20px"></i>家族关系统计</h1>
                 <h3>The Relation Statistics of Houses</h3>
                 <p align="justify" style="margin:50px 0px">在这里，你将看到我们的项目对《冰与火之歌》中出现的所有家族的关系进行了统计梳理，
                   对于家族这个实体来说，包含17种不同的关系，包括封地、箴言、分支家族等等，但是，并不是每个家族都含有这些关系，每个家族的关系都是
                   这些所有关系的子集，如果你想查看单个家族的所有关系，可以到图结构这里进行查看。在这里，我们针对每一个家族的关系，梳理了他们的数量，
                   统计了每一个关系究竟有多少，最终制作出了这个表格。当然，我们也应该知道，每一个具体的关系名称（比如头衔为海风之子），是包含很多家族的！
                 </p>
             </el-col>
        </el-row>
        <el-row>
             <el-col :span="16" :offset="4">
                 <RelationHou></RelationHou>
             </el-col>
        </el-row>
    </div>
</template>
<script>
import RelationHou from '@/components/Functions/Statis/RelationHou'
export default {
  name: 'House',
  components: {
    RelationHou
  }
}
</script>
