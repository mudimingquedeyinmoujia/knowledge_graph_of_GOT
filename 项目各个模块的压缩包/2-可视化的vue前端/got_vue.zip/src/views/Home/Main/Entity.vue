<template>
    <div>
        <el-row>
             <el-col :span="12" :offset="6">
                 <h1 style="font-size:30px"><i class="el-icon-s-help" style="margin-right:20px"></i>实体关系统计</h1>
                 <h3>The Statistics of Entities</h3>
                 <p align="justify" style="margin:50px 0px">在这里，你可以方便快捷地看到我们针对《冰与火之歌》小说的分析与百科的爬取所得到的所有人物、家族、城堡的数量统计，
                   如果你想了解所有登场过的人物、家族、城堡以便用于各种研究，那么这一个页面你绝对不能错过！我们列举了所有出现过的人物、
                   家族、城堡，如果你想继续深入了解每个实体的具体有哪些关系，可以继续到我们的图结构板块深入探索！</p>
             </el-col>
        </el-row>
        <el-row>
             <el-col :span="16" :offset="4">
                 <EntityShow></EntityShow>
                 <EntityList></EntityList>
             </el-col>
        </el-row>
    </div>
</template>
<script>
import EntityShow from '@/components/Functions/Statis/EntityShow'
import EntityList from '@/components/Functions/Statis/EntityList'
export default {
  name: 'StatisEntity',
  data () {
    return {
      myname: 'house',
      mylimit: '50'
    }
  },
  components: {
    EntityShow, EntityList
  }
}
</script>
<style scoped>
body{
  padding: 0;
  margin: 0;
}
</style>
