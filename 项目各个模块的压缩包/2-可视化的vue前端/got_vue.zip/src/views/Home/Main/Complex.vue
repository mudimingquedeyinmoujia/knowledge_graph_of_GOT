<template>
    <div>
        <el-row>
             <el-col :span="12" :offset="6">
                 <h1 style="font-size:30px"><i class="el-icon-view" style="margin-right:20px"></i>多节点关系图</h1>
                 <h3>Complex Knowledge Graph</h3>
                 <p align="justify" style="margin:50px 0px">当然，对于之前的整体关系图，我们相信很多人看到后还是不满意的，因为如果我们想对某个特定的人进行
                   深入的研究，要是使用整体关系图来进行研究，肯定是达不到预期目标的，并且还会特别卡。针对这个问题，我们分别做了两种类型的知识图谱，一种是“单节点关系图”，
                   一种是“多节点关系图”，其实不用过分纠结字面意思，你可以看成一个是力引导布局，一个是静态布局。这里是静态布局关系图，双击即可展开节点进行你的研究。
                   如果你想添加新的节点，只需要在搜索框输入即可！
                 </p>
             </el-col>
        </el-row>
        <GraphComplex></GraphComplex>
    </div>
</template>
<script>
import GraphComplex from '@/components/Functions/Visual/GraphComplex'
export default {
  name: 'Complex',
  components: {
    GraphComplex

  }
}
</script>
