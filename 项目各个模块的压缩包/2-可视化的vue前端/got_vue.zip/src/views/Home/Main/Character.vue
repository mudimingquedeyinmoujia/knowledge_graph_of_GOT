<template>
     <div>
       <el-row>
             <el-col :span="12" :offset="6">
                 <h1 style="font-size:30px"><i class="el-icon-user-solid" style="margin-right:20px"></i>人物关系统计</h1>
                 <h3>The Relation Statistics of Characters</h3>
                 <p align="justify" style="margin:50px 0px">在这里，你将看到我们的项目对《冰与火之歌》中出现的所有人物的关系进行了统计梳理，
                   对于人物这个实体来说，包含8种关系，包括执政者、宗教等等，但是，并不是每个城堡都含有这些关系，每个城堡的关系都是
                   这些所有关系的子集，如果你想查看单个城堡的所有关系，可以到图结构这里进行查看。在这里，我们针对每一个城堡的关系，梳理了他们的数量，
                   统计了每一个关系究竟有多少，最终制作出了这个表格。当然，我们也应该知道，每一个具体的关系名称（比如宗教为七神信仰），是包含很多城堡的！
                 </p>
             </el-col>
        </el-row>
        <el-row>
             <el-col :span="16" :offset="4">
                 <RelationCha></RelationCha>
             </el-col>
        </el-row>
    </div>
</template>
<script>
import RelationCha from '@/components/Functions/Statis/RelationCha'
export default {
  name: 'Character',
  components: {
    RelationCha
  }
}
</script>
