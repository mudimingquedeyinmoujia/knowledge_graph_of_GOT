<template>
    <div>
      <el-table
         :data="tabledata"
         style="width: 100%"
         height="800">
        <el-table-column
           prop="num"
           label="序号"
           width="400">
        </el-table-column>
        <el-table-column
          prop="name"
          label="名称"
          width="400">
        </el-table-column>
        <el-table-column
          prop="type"
          label="类别"
          width="350">
        </el-table-column>
      </el-table>
    </div>
</template>
<script>
import axios from 'axios'
export default {
  name: 'EntityListName',
  data () {
    return {
      target: this.baseUrl() + 'statistics',
      nameList: [],
      tabledata: []
    }
  },
  props: {
    name: String,
    limit: String
  },
  mounted () {
    this.getDatas()
  },
  methods: {
    getDatas () {
      var that = this
      //   console.log('yes i sent')
      //   console.log('send the msg')
      that.tabledata = []
      axios.get(that.target + '/' + that.name + '?limit=' + that.limit).then(function (ret) {
        // console.log(ret.data.results.bindings.length)
        that.nameList = ret.data.results.bindings
        for (var i = 0; i < that.nameList.length; i++) {
          that.tabledata.push(that.getItem(i, that.nameList[i].z.value, that.name))
        }
      })
    },
    getItem (nm, nam, tp) {
      var itm = { num: nm, name: nam, type: tp }
      return itm
    }
  }
}
</script>
