<template>
    <div>
         <RelationCore :name=cas[0] :usewhat=cas[1]></RelationCore>
    </div>
</template>
<script>
import RelationCore from '@/components/Functions/Statis/RelationCore'
export default {
  name: 'RelationCas',
  data () {
    return {
      cha: ['character', 0],
      hou: ['house', 1],
      cas: ['castle', 2]
    }
  },
  components: {
    RelationCore
  }
}
</script>
