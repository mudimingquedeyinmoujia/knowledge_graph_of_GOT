<template>
    <div>
         <RelationCore :name=cha[0] :usewhat=cha[1]></RelationCore>
    </div>
</template>
<script>
import RelationCore from '@/components/Functions/Statis/RelationCore'
export default {
  name: 'RelationCha',
  data () {
    return {
      cha: ['character', 0],
      hou: ['house', 1],
      cas: ['castle', 2]
    }
  },
  components: {
    RelationCore
  }
}
</script>
