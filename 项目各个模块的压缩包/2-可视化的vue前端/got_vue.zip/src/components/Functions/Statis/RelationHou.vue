<template>
    <div>
         <RelationCore :name=hou[0] :usewhat=hou[1]></RelationCore>
    </div>
</template>
<script>
import RelationCore from '@/components/Functions/Statis/RelationCore'
export default {
  name: 'RelationHou',
  data () {
    return {
      cha: ['character', 0],
      hou: ['house', 1],
      cas: ['castle', 2]
    }
  },
  components: {
    RelationCore
  }
}
</script>
