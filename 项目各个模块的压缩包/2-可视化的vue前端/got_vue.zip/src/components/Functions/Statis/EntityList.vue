<template>
    <div>
      <el-tabs type="border-card">
        <el-tab-pane label="全人物列表"><EntityListName :name='type[0]' :limit="1000"></EntityListName></el-tab-pane>
        <el-tab-pane label="全家族列表"><EntityListName :name='type[1]' :limit="1000"></EntityListName></el-tab-pane>
        <el-tab-pane label="全城堡列表"><EntityListName :name='type[2]' :limit="1000"></EntityListName></el-tab-pane>
      </el-tabs>
      <!-- <input type="button" value="click to get datas" @click='getDatas'>
      <input type="button" value="click to get table" @click='getTable'> -->
    </div>
</template>
<script>
import EntityListName from '@/components/Functions/Statis/EntityListName'
export default {
  name: 'EntityList',
  data () {
    return {
      type: ['character', 'house', 'castle']
    }
  },
  components: {
    EntityListName
  }

}
</script>
