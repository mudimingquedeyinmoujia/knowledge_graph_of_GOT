<template>
    <div>
        <el-row style="margin-bottom:50px">
             <el-col :span="12" :offset="6">
               <el-button @click="drawer = true" type="primary" style="margin-left: 16px;float:right">
                  打开搜索列表
               </el-button>
             </el-col>
        </el-row>

        <el-drawer
          title="我是标题"
          :visible.sync="drawer"
          :with-header="false">
          <h1>输入你想查询的实体名称</h1>
          <el-row>
             <el-col :span="22" :offset="1"><el-input prefix-icon="el-icon-search" v-model="searchName" placeholder="请输入内容"></el-input></el-col>
          </el-row>
          <el-row style="margin-top:20px">
             <el-col :span="22" :offset="1"><el-button type="primary" @click=getdatas icon="el-icon-search" style="float:right">点击查询</el-button></el-col>
          </el-row>
          <el-row style="margin-top:20px">
             <el-col :span="22" :offset="1">
                <el-table :data="gridData" height="700">
                  <el-table-column property="subject" label="Subject" width="200"></el-table-column>
                  <el-table-column property="predicate" label="Predicate" width="200"></el-table-column>
                  <el-table-column property="object" label="Object"></el-table-column>
                </el-table>
             </el-col>
          </el-row>
        </el-drawer>
        <!-- 上面是抽屉 -->
        <div id="showtablemain" style="width: auto;height: 800px;"></div>
    </div>
</template>
<script>
import axios from 'axios'
import echarts from 'echarts'
export default {
  name: 'GraphComplex',
  data () {
    return {
      jsons: { type: 'none', categories: [], nodes: [], links: [] },
      target: this.baseUrl() + 'visual/staticGraph/one',
      target2: this.baseUrl() + 'visual/getOne',
      searchName: '琼恩·雪诺',
      myGraphChart: null,
      drawer: false,
      gridData: []

    }
  },
  mounted () {
    this.getdatas()
    this.myGraphChart = echarts.init(document.getElementById('showtablemain'))
    var that = this
    this.myGraphChart.on('dblclick', function (params) {
      if (params.dataType === undefined) {
        console.log('you click undefied data')
      } else {
        that.searchName = params.data.name
        that.getdatas()
      }
    })
  },
  methods: {
    getOne () {
      var that = this
      that.gridData = []
      axios.get(that.target2 + '?name=' + that.searchName).then(function (ret) {
        var datalist = ret.data.results.bindings
        for (var i = 0; i < datalist.length; i++) {
          var item = { subject: '', predicate: '', object: '' }
          item.subject = that.parseUrl(datalist[i].x.value)
          item.predicate = that.parseUrl(datalist[i].y.value)
          item.object = that.parseUrl(datalist[i].z.value)
          that.gridData.push(item)
        }
      })
    },
    parseUrl (url) {
      var arr = url.split('/')
      var len = arr.length
      return arr[len - 1]
    },
    getdatas () {
      var that = this
      that.getOne()
      var datapost = { name: that.searchName, graphlist: that.jsons }
      axios.post(that.target, JSON.stringify(datapost)).then(function (ret) {
        that.jsons.type = ret.data.type
        that.jsons.categories = ret.data.categories
        var c = that.jsons.nodes.concat(ret.data.nodes)
        that.jsons.nodes = c
        var v = that.jsons.links.concat(ret.data.links)
        that.jsons.links = v
        that.getgraph()
      })
    },
    getgraph () {
      var that = this
      var myChart = that.myGraphChart
      myChart.showLoading()
      var option = {
        legend: {
          data: ['人物', '家族', '城堡', '属性']
        },
        series: [{
          type: 'graph',
          layout: 'none',
          animation: false,
          label: {
            position: 'right',
            formatter: '{b}'
          },
          roam: true,
          draggable: false,
          data: that.jsons.nodes.map(function (node, idx) {
            node.id = idx
            return node
          }),
          categories: that.jsons.categories,
          force: {
            edgeLength: 5,
            repulsion: 20,
            gravity: 0.1
          },
          itemStyle: {
            borderColor: '#fff',
            borderWidth: 1,
            shadowBlur: 10,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          },
          lineStyle: {
            color: 'source',
            curveness: 0.1
          },
          emphasis: {
            lineStyle: {
              width: 10
            }
          },
          focusNodeAdjacency: true,
          edges: that.jsons.links
        }]
      }

      myChart.setOption(option)
      myChart.hideLoading()
      initInvisibleGraphic()
      function initInvisibleGraphic () {
        // Add shadow circles (which is not visible) to enable drag.
        myChart.setOption({
          graphic: echarts.util.map(option.series[0].data, function (item, dataIndex) {
            // 使用图形元素组件在节点上划出一个隐形的图形覆盖住节点
            var tmpPos = myChart.convertToPixel({ seriesIndex: 0 }, [item.x, item.y])
            return {
              type: 'circle',
              id: dataIndex,
              position: tmpPos,
              shape: {
                cx: 0,
                cy: 0,
                r: 5
              },
              // silent:true,
              invisible: true,
              draggable: true,
              ondrag: echarts.util.curry(onPointDragging, dataIndex),
              z: 100 // 使图层在最高层
            }
          })
        })
        window.addEventListener('resize', updatePosition)
        myChart.on('dataZoom', updatePosition)
      }
      myChart.on('graphRoam', updatePosition)
      function updatePosition () { // 更新节点定位的函数
        myChart.setOption({
          graphic: echarts.util.map(option.series[0].data, function (item, dataIndex) {
            var tmpPos = myChart.convertToPixel({ seriesIndex: 0 }, [item.x, item.y])
            return {
              position: tmpPos
            }
          })
        })
      }
      function onPointDragging (dataIndex) { // 节点上图层拖拽执行的函数
        var tmpPos = myChart.convertFromPixel({ seriesIndex: 0 }, this.position)
        option.series[0].data[dataIndex].x = tmpPos[0]
        option.series[0].data[dataIndex].y = tmpPos[1]
        myChart.setOption(option)
        updatePosition()
      }
    }
  }
}
</script>
