<template>
    <div>
        <!-- <input type="button" value="click to get jsons" @click='getdatas'>
        <input type="button" value="click to get graph" @click='getgraph'>
        <div>获得数据</div> -->
        <el-row style="margin-bottom:50px">
             <el-col :span="12" :offset="6">
               <el-button @click="drawer = true" type="primary" style="margin-left: 16px;float:right">
                  打开搜索列表
               </el-button>
             </el-col>
        </el-row>

        <el-drawer
          title="我是标题"
          :visible.sync="drawer"
          :with-header="false">
          <h1>输入你想查询的实体名称</h1>
          <el-row>
             <el-col :span="22" :offset="1"><el-input prefix-icon="el-icon-search" v-model="searchName" placeholder="请输入内容"></el-input></el-col>
          </el-row>
          <el-row style="margin-top:20px">
             <el-col :span="22" :offset="1"><el-button type="primary" @click=getdatas icon="el-icon-search" style="float:right">点击查询</el-button></el-col>
          </el-row>
          <el-row style="margin-top:20px">
             <el-col :span="22" :offset="1">
                <el-table :data="gridData" height="700">
                  <el-table-column property="subject" label="Subject" width="200"></el-table-column>
                  <el-table-column property="predicate" label="Predicate" width="200"></el-table-column>
                  <el-table-column property="object" label="Object"></el-table-column>
                </el-table>
             </el-col>
          </el-row>
        </el-drawer>
        <!-- 上面是抽屉 -->
        <div id="showtablemain" style="width: auto;height: 800px;"></div>
    </div>
</template>
<script>
import axios from 'axios'
import echarts from 'echarts'
export default {
  name: 'GraphComplex',
  data () {
    return {
      jsons: { type: 'none', categories: [], nodes: [], links: [] },
      target: this.baseUrl() + 'visual/staticGraph/oneSimp',
      target2: this.baseUrl() + 'visual/getOne',
      searchName: '琼恩·雪诺',
      myGraphChart: null,
      drawer: false,
      gridData: []

    }
  },
  mounted () {
    this.getdatas()
    this.myGraphChart = echarts.init(document.getElementById('showtablemain'))
    var that = this
    this.myGraphChart.on('dblclick', function (params) {
      if (params.dataType === undefined) {
        console.log('you click undefied data')
      } else {
        that.searchName = params.data.name
        that.getdatas()
      }
    })
  },
  methods: {
    getOne () {
      var that = this
      that.gridData = []
      axios.get(that.target2 + '?name=' + that.searchName).then(function (ret) {
        var datalist = ret.data.results.bindings
        for (var i = 0; i < datalist.length; i++) {
          var item = { subject: '', predicate: '', object: '' }
          item.subject = that.parseUrl(datalist[i].x.value)
          item.predicate = that.parseUrl(datalist[i].y.value)
          item.object = that.parseUrl(datalist[i].z.value)
          that.gridData.push(item)
        }
      })
    },
    parseUrl (url) {
      var arr = url.split('/')
      var len = arr.length
      return arr[len - 1]
    },
    getdatas () {
      var that = this
      that.getOne()
      var datapost = { name: that.searchName, graphlist: that.jsons }
      axios.post(that.target, JSON.stringify(datapost)).then(function (ret) {
        that.jsons.type = ret.data.type
        that.jsons.categories = ret.data.categories
        var c = that.jsons.nodes.concat(ret.data.nodes)
        that.jsons.nodes = c
        var v = that.jsons.links.concat(ret.data.links)
        that.jsons.links = v
        that.getgraph()
      })
    },
    getgraph () {
      var that = this
      var myChart = that.myGraphChart
      myChart.showLoading()
      var option = {
        legend: {
          data: ['人物', '家族', '城堡', '属性']
        },
        series: [{
          type: 'graph',
          layout: 'force',
          animation: false,
          label: {
            position: 'right',
            formatter: '{b}'
          },
          roam: true,
          draggable: true,
          data: that.jsons.nodes.map(function (node, idx) {
            var newNode = { id: 0, name: '', value: 0, category: '', symbolSize: 0 }
            newNode.id = idx
            newNode.name = node.name
            newNode.value = node.value
            newNode.category = node.category
            newNode.symbolSize = node.symbolSize

            return newNode
          }),
          categories: that.jsons.categories,
          force: {
            edgeLength: 250,
            repulsion: 20,
            gravity: 0
          },
          focusNodeAdjacency: true,
          edges: that.jsons.links.map(function (node, idx) {
            var newLink = { source: 0, target: 0, label: {} }
            newLink.source = node.source
            newLink.target = node.target
            newLink.label = node.label
            newLink.label.position = 'middle'
            return newLink
          })
        }]
      }

      myChart.setOption(option)
      myChart.hideLoading()
    }
  }
}
</script>
