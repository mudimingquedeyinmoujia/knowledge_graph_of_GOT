<template>
    <div>
        <div class="one">
            <el-row>
                <el-col :span="24">
                    <h1>Friendly Links</h1>
                    <a href="https://www.hbo.com/game-of-thrones/season-8"><el-button type="primary"  circle><i class="el-icon-picture" ></i></el-button></a>
                    <a href="http://www.yyets.com/"><el-button type="primary"  circle><i class="el-icon-video-camera-solid" ></i></el-button></a>
                    <a href="https://ctyun.co/?"><el-button type="primary" circle><i class="el-icon-s-promotion" ></i></el-button></a>
                </el-col>
            </el-row>
        </div>
        <div class="two">
            <el-row>
                <el-col :span="24">
                    <p><img style="width:250px;height:30px" src="@/assets/pics/logo_small.png"></p>
                    <p style="margin-top:40px">© 2020 东软睿道, Inc. All Rights Reserved.</p>
                    <p>Member : 赵为 宋高超 刘宇 戴旭东</p>
                    <p><a href="http://www.miit.gov.cn/">津ICP备19008046号</a></p>
                </el-col>
            </el-row>
        </div>
    </div>
</template>
<style scoped>
.el-row{
    text-align: center;
}
.one{
    background-color: #4f4f4f;
    color: azure;
    padding:20px;
}
.two{
    background-color: #404040;
    color: azure;
    padding:30px;
}
a{
    text-decoration: none;
    color: azure;
}
h1{
    font-size: 25px;
}
p{
   font-size: 15px;
}
i{
    font-size: 25px;
}
.el-button{
    margin:20px;
}

</style>
