<template>
    <div>
        <el-row>
           <el-col :span="12" :offset="6">
               <!-- <el-card class="box-card">
                  <h1>欢迎来到《冰与火之歌》小说知识图谱</h1>
               </el-card> -->
               <h1 class='text'>欢迎来到《冰与火之歌》小说知识图谱</h1>
            </el-col>
        </el-row>
    </div>
</template>
<style scoped>
.el-col{
    text-align: center;

}
.text {
  font-size: 40px;
}

.item {
  padding: 18px 0;
}

.box-card {
  width: 480px;
}
</style>
