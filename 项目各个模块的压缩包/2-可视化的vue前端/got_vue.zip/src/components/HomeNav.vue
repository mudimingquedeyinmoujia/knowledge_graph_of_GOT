<template>
    <div>
      <el-row>
        <el-col :span="16">
        <el-menu :default-active="activeIndex" class="el-menu-demo" mode="horizontal" router>
            <el-menu-item index="/logo"><img style="width: 200px; height: 40px" src="@/assets/pics/logo_big.jpg"></el-menu-item>
            <el-menu-item index="/main">知识图谱</el-menu-item>
            <el-menu-item index="/project">项目简介</el-menu-item>
            <!-- <el-menu-item index="/team">相关文档</el-menu-item> -->
        </el-menu>
        </el-col>
        <el-col :span="8"><a href="http://caballer.top:8002"><el-button type="primary" style="float:right;margin-top:10px"><i class="el-icon-share">去社区看一看</i></el-button></a></el-col>
      </el-row>
    </div>
</template>
<script>
export default {
  name: 'HomeNav',
  data () {
    return {
      pic_src: '../assets/pics/logo_big.jpg',
      activeIndex: '/main'
    }
  }
}
</script>
<style scoped>
.el-menu.el-menu--horizontal{
    border-bottom:0px
}
</style>
