<template>
    <div>
    <el-card :body-style="{ padding: '0px' }" shadow="hover">
      <img :src=picsrc class="image">
      <div style="padding: 14px;">
        <h1><i :class=whattype[type].icon></i>{{whattype[type].title}}</h1>
        <div class="bottom clearfix">
          <!-- <time class="time">{{ currentDate }}</time> -->
          <p>{{whattype[type].describe}}</p>
          <router-link :to=whattype[type].route><el-button type="primary" icon="el-icon-share" class="button">Have a Look</el-button></router-link>
        </div>
      </div>
    </el-card>
    </div>
</template>
<script>
export default {
  data () {
    return {
      whattype: [
        { title: '整体关系图', describe: '在整体关系图模块，你可以得到小说中所有的人物、家族、城堡的关系，考虑到图结构过于庞大，我们提供图结构尺寸选择功能，您可以自定义要显示的图结构关系数量', route: '/global', icon: 'el-icon-view' },
        { title: '单节点关系图', describe: '在单节点关系图模块，使用力引导布局，你可以进行小说中某单个人物的关系分析，也可以开启搜索引擎自行往图里添加你想要的节点', route: '/simple', icon: 'el-icon-view' },
        { title: '多节点关系图', describe: '在单节点关系图模块，使用可拖拽的节点结构，你可以进行小说中某单个人物的关系分析，也可以开启搜索引擎自行往图里添加你想要的节点', route: '/complex', icon: 'el-icon-view' }
      ],
      picsrc: null
    }
  },
  mounted () {
    if (this.type === 0) {
      this.picsrc = require('@/assets/pics/visualdemoall_0.png')
    } else if (this.type === 1) {
      this.picsrc = require('@/assets/pics/visualdemosimple_0.png')
    } else {
      this.picsrc = require('@/assets/pics/visualdemocomplex_0.png')
    }
  },
  props: {
    type: Number
  }
}
</script>
<style scoped>
  .time {
    font-size: 13px;
    color: #999;
  }

  .button {
    float: right;
  }

  .image {
    width: 100%;
    display: block;
  }

  .clearfix:before,
  .clearfix:after {
      display: table;
      content: "";
  }

  .clearfix:after {
      clear: both
  }
  p{
      line-height: 150%;
  }
  h1 i{
      margin-right: 20px;
  }
</style>
