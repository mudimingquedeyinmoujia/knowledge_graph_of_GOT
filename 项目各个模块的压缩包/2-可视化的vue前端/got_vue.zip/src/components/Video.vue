<template>
    <div>
        <video
            class="video-js vjs-default-skin vjs-big-play-centered"
            controls="false"
            autoplay="muted"
            preload="auto"
            loop="true"
            poster="../assets/pics/p1.jpg">
            <source src="../assets/pics/videomain.mp4" type="video/mp4" >
        </video>
    </div>
</template>

<script>
export default {
  name: 'Video',
  data () {
    return {}
  }
}
</script>

<style scoped>
.video-js {
    width: 100%;
    height: 450px;
}
</style>
