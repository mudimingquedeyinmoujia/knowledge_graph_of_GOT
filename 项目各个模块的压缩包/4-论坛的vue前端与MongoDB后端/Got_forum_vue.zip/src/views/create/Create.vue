<template>
  <basic-panel :isHeader="false" class="panel">
    <template>
      <div class="main-title">
        发布话题
      </div>
      
      <div class="input-form">
        <form action="">
          <!-- 选择话题标签 -->
          <div class="tag">
            <span>选择板块：</span>
<!--            <select name="tag" v-model="tag">-->
<!--              <option class="option" value="share">分享</option>-->
<!--              <option class="option" value="ask">问答</option>-->
<!--              <option class="option" value="job">热门</option>-->
<!--              <option class="option" value="test">最新</option>-->
<!--            </select>-->
            <el-select v-model="tag" clearable placeholder="请选择" name="tag">
              <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value"></el-option>
            </el-select>
          </div>
          
          <!-- 输入标题 -->
          <div class="title">
<!--            <input type="text" placeholder="标题" v-model="title">-->

            <el-input placeholder="请输入标题" v-model="title" clearable></el-input>

          </div>
        </form>
      </div>
      
      <!-- 富文本编辑器 -->
      <wang-editor ref="editor"></wang-editor>
      
      <!-- 提交 -->
<!--      <button class="submit" @click="submit">提交</button>-->
      <br/>
      <el-button :plain="true" @click="submit">提交</el-button>
    </template>
  </basic-panel>
  
</template>

<script>
  import BasicPanel from '@components/common/panel/BasicPanel'
  import WangEditor from '@components/common/WangEditor.vue'
  import {sendTopic} from '@network/sendData.js'
  
  export default{
    name: 'create',
    data() {
      return {
        tag: null,
        title: null,
        content: null,
        options: [{
          value: 'share',
          label: '分享'
        }, {
          value: 'ask',
          label: '问答'
        }, {
          value: 'job',
          label: '热门'
        }, {
          value: 'test',
          label: '最新'
        }],
        // 发送tag前转换成中文
        tagName: {
          share: '分享',
          ask: '问答',
          job: '求职',
          test: '测试'
        }
      }
    },
    components: {
      BasicPanel,
      WangEditor
    },
    methods: {
      // 提交文章
      submit() {
        // 提交数据体包括tag, title, content, author
        var tag = this.tagName[this.tag]
        var title = this.title
        var content = this.$refs.editor.editorContent
        var author = this.$store.state.user.username
        
        // 提交前检查：是否登录，信息是否完整， 文章内容是否达标
        var text = this.$refs.editor.editor.txt.text()
        if(!author) {
          // alert('请登录后再尝试')
          this.$message({
          showClose: true,
          message: '请登录后再尝试',
          type: 'error',
          center: true
        });
          return
        }
        else if(!tag || !title || !text) {
          // alert('请填写完整的信息')
          this.$message({
          showClose: true,
          message: '请填写完整的信息',
          type: 'error',
          center: true
        });
          return
        }
        else if(title.length > 20) {
          // alert('标题过长，请输入20个字符以内的标题')
          this.$message({
          showClose: true,
          message: '标题过长，请输入20个字符以内的标题',
          type: 'error',
          center: true
        });
          return
        }
        else if(text.length <10) {
          // alert('文章内容必须大于10个字符')
          this.$message({
          showClose: true,
          message: '文章内容必须大于10个字符',
          type: 'error',
          center: true
        });
          return
        }
        
        sendTopic({tag, title, content, author})
          .then(res => {
            if(res.data.msg == 'ok') {
              // alert('提交成功')
              this.$message({
          showClose: true,
          message: '提交成功',
          type: 'success',
          center: true
        });
              this.$router.replace('/')
              location.reload()
            }
            else if(res.data.msg == 'login'){
              // alert('请登录后再进行操作')
              this.$message({
          showClose: true,
          message: '请登录后再进行操作',
          type: 'error',
          center: true
        });
              this.$router.replace('/login')
            }
            else {
              // alert('服务器繁忙，请稍后再试')
              this.$message({
          showClose: true,
          message: '服务器繁忙，请稍后再试',
          type: 'error',
          center: true
        });
              this.$router.replace('/')
            }
          })
      },
    }
  }
</script>


<style lang="scss" scoped>
  .main-title{
    @include main-title
  }
  .input-form{
    margin-top: 20px ;
    margin-bottom: 40px;
  }
  .tag {
    span {
      font-size: 16px;
    }
    select {
      display: inline-block;
      width: 100px;
      height: 30px;
      border: 1px solid $bgGrey;
      border-radius: 5px;
      outline: none;
      text-align: center;
      transition: box-shadow 0.25s ease;
      &:hover{
        box-shadow: 0 1px 4px rgba(0, 0, 0, 0.15);
      }
    }
  }
  .title {
    margin-top: 20px;
    width: 80%;
    height: 30px;
    border: 1px solid $bgGrey;
    border-radius: 5px;
    padding-left: 8px;
    transition: box-shadow 0.25s ease;
    &:hover{
      box-shadow: 0 1px 4px rgba(0, 0, 0, 0.15);
    }
    span {
      font-size: 16px;
    }
    input{
      border: none;
      outline: none;
      line-height: 30px;
      width: 100%;
      background: none;
    }
  }
  .submit{
    @include basic-button;
    margin: 10px auto 0 auto;
  }
</style>
