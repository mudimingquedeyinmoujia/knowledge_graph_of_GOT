<template>
  <div class="index-footer">
    <a>© 2020 东软睿道 码到成功组</a>
  </div>
</template>

<script>
  export default {
    name: 'index-footer',
    data() {
      return {
        
      }
    }
  }
</script>

<style scoped>
  .index-footer{
    clear: both;
    text-align: center;

  }
</style>
