<template>
  <div>
    <h3>近期发布话题</h3>
    <p>未开发</p>
    <br>
    <br>
    <h3>收藏的话题</h3>
    <p>未开发</p>
    <br>
    <br>
  </div>
</template>

<script>
  export default {
    name: 'profile-main',
    data() {
      return {
        
      }
    }
  }
</script>

<style lang="scss" scoped>
  
</style>
