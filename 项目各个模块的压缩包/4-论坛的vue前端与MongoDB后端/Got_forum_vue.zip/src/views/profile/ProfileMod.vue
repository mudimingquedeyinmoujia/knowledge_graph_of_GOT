<template>
  <div class="porfile-mod">
    <form class="input-form">
      <div class="input-box">
        <label for="oldpwd">旧密码</label>
        <div class="right-box">
          <div class="good-input">
<!--            <input type="password" name="oldpwd" v-model="oldpwd" id="oldpwd">-->
            <el-input placeholder="请输入旧密码" v-model="oldpwd" name="oldpwd" type="password" id="oldpwd" clearable></el-input>
          </div>
        </div>
      </div>
      <div class="input-box">
        <label for="newpwd">新密码</label>
        <div class="right-box">
          <div class="good-input">
<!--            <input type="password" name="newpwd" v-model="newpwd" id="newpwd" @input="inputNewpwd">-->
            <el-input placeholder="请输入新密码" v-model="newpwd" name="newpwd" type="password" id="newpwd" @input="inputNewpwd" clearable></el-input>
          </div>
          <p class="alert" v-show="newpwd">{{newpwdTips}}</p>
        </div>
      </div>
      <div class="input-box">
        <label for="confirm">确认新密码</label>
        <div class="right-box">
          <div class="good-input">
            <el-input placeholder="请再次输入密码" v-model="confirm" name="confirm" type="password" id="confirm" @input="inputConfirm" clearable></el-input>
<!--            <input type="password" name="confirm" v-model="confirm" id="confirm" @input="inputConfirm">-->
          </div>
          <p class="alert" v-show="confirm">{{confirmTips}}</p>
        </div>
      </div>
      <div class="submit-box">
<!--        <button class="submit" @click.prevent="submit">修改密码</button>-->
<!--        <el-button type="primary" @click.prevent="submit">修改密码</el-button>-->
          <el-button :plain="true" @click.prevent="submit">修改密码</el-button>
      </div>
    </form>
  </div>
</template>

<script>
  import {modPwd} from '@network/sendData.js'
  
  export default {
    name: 'profile-mod',
    data() {
      return {
        oldpwd: '',
        newpwd: '',
        confirm: '',
        isPasswordAvailable: false,
        isConfirmAvailable: false,
        newpwdTips: null,
        confirmTips: null
      }
    },
    methods: {
      submit() {
        if(this.isConfirmAvailable && this.isPasswordAvailable && this.oldpwd) {
          if(this.oldpwd == this.newpwd) {
            // alert('修改后的密码不能与原密码相同！')
              this.$message({
          showClose: true,
          message: '修改后的密码不能与原密码相同！',
          type: 'error',
                  center: true,
        });
          }
          else{
            modPwd({oldpwd: this.oldpwd, newpwd: this.newpwd})
              .then(res => {
                if(res.data.msg == 'ok') {
                  // alert('修改成功')
                    this.$message({
          showClose: true,
          message: '修改成功',
          type: 'success',
                  center: true,
        });
                  this.$router.push('/profile/main')
                }
                else {
                  // alert('密码错误，修改失败')
                    this.$message({
          showClose: true,
          message: '密码错误，修改失败',
          type: 'error',
                  center: true,
        });
                }
              })
          }
        }
        else {
          // alert('请检查输入')
            this.$message({
          showClose: true,
          message: '请检查输入',
          type: 'error',
                  center: true,
        });
        }
      },
      // 验证密码
      inputNewpwd() {
        if(!this.newpwd) {
          this.isPasswordAvailable = false
        }
        else if(this.newpwd.length < 6 || this.newpwd.length > 12) {
          this.isPasswordAvailable = false
          this.newpwdTips = '密码长度应为6-12字符'
        }
        else if(/\s/.test(this.newpwd)) {
          this.isPasswordAvailable = false
          this.newpwdTips = '密码不应包含空格'
        }
        else {
          this.isPasswordAvailable = true
          this.newpwdTips = '√'
        }
        this.inputConfirm()
      },
      // 验证再次输入的密码
      inputConfirm() {
        if(!this.confirm) {
          this.isConfirmAvailable = false
        }
        else if(this.newpwd == this.confirm) {
          this.isConfirmAvailable = true
          this.confirmTips = '√'
        }
        else if(this.confirm !== this.newpwd) {
          this.isConfirmAvailable = false
          this.confirmTips = '两次输入密码不一致'
        }
      },
    }
  }
</script>

<style lang="scss" scoped>
  .input-form{
    margin-top: 20px;
    display: flex;
    flex-direction: column;
    align-items: center;
  }
  .input-box{
    /*各个框之间的间隔距离是20*/
    margin-bottom: 20px;
    display: flex;
    label{
      width: 100px;
      text-align: right;
      margin-right: 10px;
      margin-left: -50px;
      font-size: 16px;
      padding-top: 3px;
    }
    .right-box{
      flex: 1;
      display: flex;
      flex-direction: column;
      .good-input{
        @include good-input;
      }
      .alert{
        margin-top: 10px;
      }
    }
  }
  .submit-box{
    .submit{
      @include basic-button;
      margin-left: 65px;
    }
    a{
      margin-left: 10px;
      color: #1E88E5;
      text-decoration: underline;
      cursor: pointer;
    }
  }
</style>
