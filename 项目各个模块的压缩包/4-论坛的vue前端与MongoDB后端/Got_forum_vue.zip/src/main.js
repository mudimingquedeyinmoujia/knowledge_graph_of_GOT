// 引入vue
import Vue from 'vue'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import axios from 'axios'
// 引入vue路由
import router from './router/index.js'

// 引入vuex
import store from './store'
Vue.prototype.$store = store
Vue.prototype.$axios = axios

Vue.use(ElementUI)

import App from './App.vue'


Vue.config.productionTip = false

new Vue({
  router: router,
  render: h => h(App),
}).$mount('#app')
